import React, { useState, useEffect } from 'react';
import { UploadZone } from './components/UploadZone';
import { generateTryOnImage, generateFashionVideo } from './services/geminiService';
import { processFile, urlToFile } from './utils';
import { FileData, AppStatus, GenerationResult } from './types';

// Extended sample data matching user's specific wardrobe requests
const SAMPLE_CLOTHES = [
  // Tops (Matching User Images)
  { id: 1, type: 'top', url: 'https://images.unsplash.com/photo-1621334692791-37599e5a4071?auto=format&fit=crop&w=600&q=80', label: 'Plaid Flannel' }, // Matches Plaid Shirt
  { id: 2, type: 'top', url: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=600&q=80', label: 'Cream Cable Knit' }, // Matches Cream Sweater
  { id: 3, type: 'top', url: 'https://images.unsplash.com/photo-1624225205256-11e74f3586aa?auto=format&fit=crop&w=600&q=80', label: 'Burgundy Knit' }, // Matches Argyle Sweater vibe
  { id: 4, type: 'top', url: 'https://images.unsplash.com/photo-1551488852-7a06a218d6bf?auto=format&fit=crop&w=600&q=80', label: 'Red Long Sleeve' }, // Matches Red Top
  { id: 5, type: 'top', url: 'https://images.unsplash.com/photo-1539008835657-9e8e9680c956?auto=format&fit=crop&w=600&q=80', label: 'Black Dress' }, // Matches Black Dress
  
  // Bottoms (Matching User Images)
  { id: 6, type: 'bottom', url: 'https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?auto=format&fit=crop&w=600&q=80', label: 'Dark Wash Jeans' }, // Matches Blue Jeans
  { id: 7, type: 'bottom', url: 'https://images.unsplash.com/photo-1582552938357-32b906df40cb?auto=format&fit=crop&w=600&q=80', label: 'Denim Shorts' },

  // Shoes (Kept for functionality)
  { id: 8, type: 'shoe', url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80', label: 'Red Sneakers' },
  { id: 9, type: 'shoe', url: 'https://images.unsplash.com/photo-1560769629-975e13f01b35?auto=format&fit=crop&w=600&q=80', label: 'Leather Shoes' },
  { id: 10, type: 'shoe', url: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=600&q=80', label: 'Sport Runners' },
];

const App: React.FC = () => {
  const [personImage, setPersonImage] = useState<FileData | null>(null);
  
  // New State for Full Outfit
  const [topImage, setTopImage] = useState<FileData | null>(null);
  const [bottomImage, setBottomImage] = useState<FileData | null>(null);
  const [shoeImage, setShoeImage] = useState<FileData | null>(null);

  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [result, setResult] = useState<GenerationResult>({});
  const [error, setError] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState<boolean>(false);
  const [loadingSample, setLoadingSample] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'top' | 'bottom' | 'shoe'>('all');

  useEffect(() => {
    checkApiKey();
  }, []);

  const checkApiKey = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio?.hasSelectedApiKey) {
      const has = await aistudio.hasSelectedApiKey();
      setHasKey(has);
    }
  };

  const handleSelectKey = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio?.openSelectKey) {
      await aistudio.openSelectKey();
      setHasKey(true);
    }
  };

  const handleSampleSelect = async (item: typeof SAMPLE_CLOTHES[0]) => {
    try {
      setLoadingSample(item.id);
      setError(null);
      
      const filename = `${item.label.replace(/\s+/g, '-').toLowerCase()}.jpg`;
      const file = await urlToFile(item.url, filename);
      const fileData = await processFile(file);

      if (item.type === 'top') setTopImage(fileData);
      else if (item.type === 'bottom') setBottomImage(fileData);
      else if (item.type === 'shoe') setShoeImage(fileData);

    } catch (err) {
      console.error(err);
      setError("Could not load this sample. Please try uploading manually.");
    } finally {
      setLoadingSample(null);
    }
  };

  const handleTryOn = async () => {
    // Require person and at least one item
    if (!personImage) return;
    if (!topImage && !bottomImage && !shoeImage) {
        setError("Please select at least one item to wear.");
        return;
    }

    if (!hasKey) {
      await handleSelectKey();
    }

    setStatus(AppStatus.GENERATING_IMAGE);
    setError(null);
    setResult({});

    try {
      const imageUrl = await generateTryOnImage(
        personImage,
        topImage,
        bottomImage,
        shoeImage
      );
      setResult({ imageUrl });
      setStatus(AppStatus.IMAGE_READY);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to generate image.");
      setStatus(AppStatus.ERROR);
    }
  };

  const handleGenerateVideo = async () => {
    if (!result.imageUrl) return;
    
    if (!hasKey) {
        await handleSelectKey();
    }

    setStatus(AppStatus.GENERATING_VIDEO);
    setError(null);

    try {
      const videoUrl = await generateFashionVideo(result.imageUrl);
      setResult(prev => ({ ...prev, videoUrl }));
      setStatus(AppStatus.VIDEO_READY);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to generate video.");
      setStatus(AppStatus.IMAGE_READY);
    }
  };

  const reset = () => {
    setPersonImage(null);
    setTopImage(null);
    setBottomImage(null);
    setShoeImage(null);
    setStatus(AppStatus.IDLE);
    setResult({});
    setError(null);
  };

  const filteredSamples = activeTab === 'all' 
    ? SAMPLE_CLOTHES 
    : SAMPLE_CLOTHES.filter(i => i.type === activeTab);

  return (
    <div className="min-h-screen bg-white text-stone-900 selection:bg-stone-900 selection:text-white pb-20">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-sm border-b border-stone-100">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-serif font-bold tracking-tighter text-stone-900">
              VOGUE<span className="font-sans text-sm align-top font-normal tracking-widest ml-1 text-stone-500">AI</span>
            </h1>
          </div>
          {!hasKey && (
             <button 
              onClick={handleSelectKey}
              className="text-[10px] uppercase tracking-[0.2em] font-semibold bg-stone-100 hover:bg-stone-200 px-4 py-2 text-stone-900 transition-colors"
             >
               API Key Required
             </button>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 pt-32">
        
        {/* Intro */}
        {status === AppStatus.IDLE && (
            <div className="text-center mb-12 border-b border-stone-100 pb-10">
            <p className="text-xs font-bold uppercase tracking-[0.3em] text-stone-400 mb-4">The Complete Look</p>
            <h2 className="text-5xl md:text-7xl font-serif font-medium mb-4 leading-none italic text-stone-900">
                Style the <br/><span className="not-italic">Silhouette.</span>
            </h2>
            <p className="text-stone-500 max-w-lg mx-auto font-light text-md">
                Upload your muse and curate the Top, Bottom, and Footwear.
            </p>
            </div>
        )}

        {/* Status Messages */}
        {error && (
            <div className="mb-8 p-4 bg-red-50 border-l-2 border-red-900 text-red-800 text-center font-serif italic text-sm">
                {error}
            </div>
        )}

        {/* WORKSPACE GRID */}
        <div className={`grid grid-cols-1 lg:grid-cols-12 gap-1 lg:h-[600px] border border-stone-200 bg-stone-200 mb-12 transition-all duration-700 ${status !== AppStatus.IDLE ? 'opacity-40 grayscale pointer-events-none' : ''}`}>
          
          {/* LEFT: THE MUSE (Larger) */}
          <div className="lg:col-span-8 bg-white h-[500px] lg:h-full">
            <UploadZone
              label="The Muse"
              selectedFile={personImage}
              onFileSelect={setPersonImage}
              className="h-full w-full"
              icon={
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={0.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              }
            />
          </div>

          {/* RIGHT: THE WARDROBE (Stack of 3) */}
          <div className="lg:col-span-4 flex flex-col gap-px h-full">
             
             {/* TOP SLOT */}
             <div className="flex-1 bg-white min-h-[180px]">
                <UploadZone
                    label="Top"
                    selectedFile={topImage}
                    onFileSelect={setTopImage}
                    className="h-full"
                    compact={true}
                    icon={
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 6h16M4 6l1.5 12h13L20 6M4 6l1-2h14l1 2" />
                        </svg>
                    }
                />
             </div>

             {/* BOTTOM SLOT */}
             <div className="flex-1 bg-white min-h-[180px]">
                <UploadZone
                    label="Bottom"
                    selectedFile={bottomImage}
                    onFileSelect={setBottomImage}
                    className="h-full"
                    compact={true}
                    icon={
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 6h16v12a2 2 0 01-2 2H6a2 2 0 01-2-2V6z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 6v14" />
                        </svg>
                    }
                />
             </div>

             {/* SHOES SLOT */}
             <div className="flex-1 bg-white min-h-[180px]">
                <UploadZone
                    label="Footwear"
                    selectedFile={shoeImage}
                    onFileSelect={setShoeImage}
                    className="h-full"
                    compact={true}
                    icon={
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    }
                />
             </div>

          </div>
        </div>

        {/* WARDROBE SELECTOR */}
        {status === AppStatus.IDLE && (
          <div className="mb-20">
            <div className="flex items-end gap-6 mb-6 border-b border-stone-100 pb-4">
               <h3 className="font-serif italic text-2xl text-stone-900">Wardrobe</h3>
               <div className="flex gap-4">
                  {['all', 'top', 'bottom', 'shoe'].map(tab => (
                      <button 
                        key={tab}
                        onClick={() => setActiveTab(tab as any)}
                        className={`text-[10px] uppercase tracking-widest hover:text-stone-900 transition-colors ${activeTab === tab ? 'text-stone-900 font-bold border-b border-stone-900' : 'text-stone-400'}`}
                      >
                        {tab === 'shoe' ? 'Footwear' : tab}s
                      </button>
                  ))}
               </div>
            </div>
            
            <div className="overflow-x-auto pb-6 scrollbar-hide">
              <div className="flex gap-4 min-w-max">
                {filteredSamples.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleSampleSelect(item)}
                    disabled={loadingSample !== null}
                    className={`
                      group relative w-36 h-48 flex-shrink-0 bg-stone-50 border transition-all duration-300 overflow-hidden
                      ${(item.type === 'top' && topImage?.previewUrl.includes(item.url)) || 
                        (item.type === 'bottom' && bottomImage?.previewUrl.includes(item.url)) ||
                        (item.type === 'shoe' && shoeImage?.previewUrl.includes(item.url)) ||
                         loadingSample === item.id ? 'border-stone-900 ring-1 ring-stone-900' : 'border-stone-200 hover:border-stone-400'}
                    `}
                  >
                    <img 
                      src={item.url} 
                      alt={item.label} 
                      crossOrigin="anonymous"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    
                    {loadingSample === item.id && (
                      <div className="absolute inset-0 bg-white/60 flex items-center justify-center z-10">
                        <div className="w-5 h-5 border-2 border-stone-900 border-t-transparent rounded-full animate-spin"></div>
                      </div>
                    )}
                    
                    {/* Type Badge */}
                    <div className="absolute top-2 right-2 px-2 py-1 bg-white/90 text-[8px] uppercase tracking-widest font-bold z-10">
                        {item.type}
                    </div>

                    <div className="absolute bottom-0 left-0 right-0 p-2 bg-white/95 translate-y-full group-hover:translate-y-0 transition-transform duration-300 z-10">
                      <p className="text-[9px] uppercase tracking-widest text-center text-stone-900 font-semibold">{item.label}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Action Button */}
        {status === AppStatus.IDLE && (
          <div className="flex flex-col items-center justify-center mb-24">
            <button
              onClick={handleTryOn}
              disabled={!personImage || (!topImage && !bottomImage && !shoeImage)}
              className={`
                px-12 py-5 text-sm uppercase tracking-[0.25em] font-semibold transition-all duration-300
                ${personImage && (topImage || bottomImage || shoeImage)
                  ? 'bg-stone-900 text-white hover:bg-stone-800 hover:px-14 shadow-xl shadow-stone-200' 
                  : 'bg-stone-200 text-stone-400 cursor-not-allowed'}
              `}
            >
              Curate Complete Look
            </button>
          </div>
        )}

        {/* Loading States */}
        {(status === AppStatus.GENERATING_IMAGE || status === AppStatus.GENERATING_VIDEO) && (
          <div className="flex flex-col items-center justify-center py-32">
            <div className="w-px h-24 bg-stone-200 overflow-hidden relative mb-6">
                 <div className="absolute inset-0 bg-stone-900 animate-[ping_1.5s_ease-in-out_infinite]"></div>
            </div>
            <p className="font-serif text-2xl italic text-stone-900 animate-pulse">
              {status === AppStatus.GENERATING_IMAGE ? "Fitting the outfit..." : "Filming the runway..."}
            </p>
          </div>
        )}

        {/* Results Section */}
        {(status === AppStatus.IMAGE_READY || status === AppStatus.VIDEO_READY || (status === AppStatus.ERROR && result.imageUrl)) && (
          <div className="animate-fade-in-up">
            
            {/* Image Result */}
            {result.imageUrl && (
              <div className="mb-24">
                <div className="flex items-center gap-4 mb-8 justify-center">
                    <div className="h-px bg-stone-200 w-12"></div>
                    <h3 className="text-3xl font-serif italic">The Collection</h3>
                    <div className="h-px bg-stone-200 w-12"></div>
                </div>
                
                <div className="flex flex-col items-center">
                  <div className="p-4 bg-white shadow-[0_20px_50px_-12px_rgba(0,0,0,0.1)] border border-stone-100 max-w-2xl w-full">
                    <div className="aspect-[3/4] w-full overflow-hidden bg-stone-100">
                        <img 
                        src={result.imageUrl} 
                        alt="Generated Try-On" 
                        className="w-full h-full object-cover"
                        />
                    </div>
                    <div className="pt-6 pb-2 flex justify-between items-end border-t border-stone-100 mt-4">
                        <div>
                            <p className="text-[10px] uppercase tracking-widest text-stone-400">Season</p>
                            <p className="font-serif italic text-lg">Spring / Summer 25</p>
                        </div>
                        <a 
                            href={result.imageUrl} 
                            download="my-style.png"
                            className="text-xs font-bold uppercase tracking-widest border-b border-stone-900 pb-1 hover:text-stone-600 hover:border-stone-600 transition-colors"
                        >
                            Download
                        </a>
                    </div>
                  </div>

                  {/* Generate Video Call to Action */}
                  {!result.videoUrl && status !== AppStatus.GENERATING_VIDEO && (
                    <div className="mt-16 text-center">
                      <p className="font-serif text-xl italic text-stone-500 mb-6">Bring the editorial to life</p>
                      <button
                        onClick={handleGenerateVideo}
                        className="group relative inline-flex items-center justify-center px-8 py-4 bg-transparent border border-stone-300 hover:border-stone-900 transition-colors overflow-hidden"
                      >
                         <span className="absolute w-0 h-0 transition-all duration-500 ease-out bg-stone-900 rounded-full group-hover:w-80 group-hover:h-80 opacity-5"></span>
                         <span className="relative flex items-center gap-3 text-sm uppercase tracking-widest font-semibold text-stone-900">
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M8 5v14l11-7z"/>
                            </svg>
                            Generate Runway Video
                         </span>
                      </button>
                      {!hasKey && <p className="text-[10px] uppercase tracking-widest text-stone-400 mt-4">Premium Feature • Paid Key Required</p>}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Video Result */}
            {result.videoUrl && (
              <div className="max-w-4xl mx-auto" id="video-result">
                 <div className="flex items-center gap-4 mb-12 justify-center">
                    <div className="h-px bg-stone-200 w-24"></div>
                    <h3 className="text-3xl font-serif italic text-stone-900">On The Runway</h3>
                    <div className="h-px bg-stone-200 w-24"></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                    <div className="order-2 md:order-1">
                        <h4 className="font-serif text-4xl mb-4">Motion &<br/>Emotion</h4>
                        <p className="text-stone-500 font-light leading-relaxed mb-8">
                            Experience the flow of fabric and the confidence of the walk. 
                            Veo technology brings static fashion into a dynamic reality.
                        </p>
                        <button 
                            onClick={reset}
                            className="text-xs font-bold uppercase tracking-widest border-b border-stone-300 pb-1 hover:border-stone-900 transition-colors"
                        >
                            Create New Look
                        </button>
                    </div>
                    <div className="order-1 md:order-2">
                        <div className="relative p-2 border border-stone-200 shadow-2xl">
                            <video 
                            src={result.videoUrl} 
                            controls 
                            autoPlay 
                            loop 
                            className="w-full h-auto bg-stone-100"
                            />
                        </div>
                    </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="mt-32 border-t border-stone-100 py-12 text-center">
          <p className="font-serif italic text-stone-400">StyleAI Magazine &copy; 2025</p>
      </footer>
    </div>
  );
};

export default App;