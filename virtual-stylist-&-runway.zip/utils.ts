import { FileData } from './types';

export const readFileAsBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove the Data URL prefix (e.g., "data:image/jpeg;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const processFile = async (file: File): Promise<FileData> => {
  const base64 = await readFileAsBase64(file);
  const previewUrl = URL.createObjectURL(file);
  return {
    file,
    previewUrl,
    base64,
    mimeType: file.type,
  };
};

export const urlToFile = async (url: string, filename: string): Promise<File> => {
  const response = await fetch(url, { mode: 'cors' });
  if (!response.ok) {
    throw new Error(`Failed to fetch image: ${response.statusText}`);
  }
  const blob = await response.blob();
  return new File([blob], filename, { type: blob.type });
};